Dental Expert — 24 ekranli lokal prototip

1. ZIPni oching.
2. demo.html faylini Safari yoki Chrome brauzerida oching.
3. Pastki 5 tugma va ekrandagi amallarni bosing. Telefonning past-o‘ngidagi tanlash menyusidan 24 ekranning istalganini ochishingiz mumkin.
4. screenshots/ ichida 24 sahifaning JPG rasmlari bor.

Bu demo: haqiqiy ro‘yxatdan o‘tish, email, Apple/Google kirishi, forum serveri va tibbiy xizmat mavjud emas.
